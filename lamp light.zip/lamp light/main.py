# A prototype jigga jigga program
# Created by Alex Z
# Started 2021/06/16

# Import libraries

import pygame

# Initializing the pygame screen variables.

pygame.init()
screen = pygame.display.set_mode((800, 500))  # Creating the display screen.

# Initializing board variables

scores = [0, 0, 0, 0]  # the scores of the players
round_number = 0
size = 20  # Size of the board
board = [[[0, 0, 0, 0, 1] for i in range(size)] for j in range(size)]  # Entries of the form: [l1, l2, l3, l4, p]
# representing the light levels of players 1, 2, 3, and 4, and the point value of the square respectively.

PlayerAIs = []  # A list of all the imported functions.
PlayerColors = []  # A list of all the colors of the players
PlayerNames = []  # A list of the names of the players

# Import your AI here:

from SampleAIs import NihilNelly
from SampleAIs import RandomRandy
from SampleAIs import CenterCarly
from SampleAIs import ProtectivePeter
from SampleAIs import AggressiveAndy

PlayerAIs.append(NihilNelly)
PlayerColors.append([0, 0, 0])
PlayerNames.append("Nihil Nelly")

PlayerAIs.append(RandomRandy)
PlayerColors.append([1, 0, 0])
PlayerNames.append("Random Randy 1")

PlayerAIs.append(RandomRandy)
PlayerColors.append([0, 0, 1])
PlayerNames.append("Random Randy 2")

PlayerAIs.append(RandomRandy)
PlayerColors.append([1, 1, 0])
PlayerNames.append("Random Randy 3")

PlayerAIs.append(CenterCarly)
PlayerColors.append([0, 1, 0])
PlayerNames.append("Center Carly")

PlayerAIs.append(ProtectivePeter)
PlayerColors.append([.5, 0, .5])
PlayerNames.append("Protective Peter")

PlayerAIs.append(AggressiveAndy)
PlayerColors.append([0, 1, 1])
PlayerNames.append("Aggressive Andy")


# from yourFileName import yourAI
# PlayerAIs.append(yourAI)
# PLayerColors.append(yourAIColor) # in [r,g,b] format (use values between 1 and 0)
# PlayerNames.append(yourAIName)  # as a string

PlayerNumbers = [int(input("Enter the number of player " + str(i + 1) + ": ")) for i in range(4)]  # Inputting the AIs used.

Players = [PlayerAIs[PlayerNumbers[i]] for i in range(4)]  # Creating the player list
colors = [PlayerColors[PlayerNumbers[i]] for i in range(4)]  # The colors of the players


def caculate_score(player_index):  # Calculates the current score of the player with index player_index.
    score = 0  # Temporary score variable
    for i in range(size):  # Iterating over the board
        for j in range(size):
            if whose_square(i, j) == player_index:
                score += board[i][j][4]
    return score


def add_lights(list, banned_indexes=[]):  # Adds a light for a player at the position given.
    for i in range(size):
        for j in range(size):
            index = 0
            for row, col in list:
                if index not in banned_indexes:
                    distance_squared = (abs(row - i) + 1) ** 2 + (abs(col - j) + 1) ** 2
                    board[i][j][index] += 1 / distance_squared
                index += 1


def process_board(player_index):  # Converts the board to the state that your AI will receive it.
    new_board = []  # Initializing the new board.
    for row in board:
        new_row = []
        for square in row:
            new_square = []
            for i in range(4):  # Reindexing the board to make your AI index 0.
                new_square.append(square[(i + player_index) % 4])
            new_square.append(square[4])
            new_row.append(new_square)
        new_board.append(new_row)
    return new_board


def whose_square(row, col):  # Determines who controls the square, ties go to nobody
    square = board[row][col]
    winner = None
    maximum = -1
    for player in range(4):
        if square[player] > maximum:
            winner = player
            maximum = square[player]
        elif square[player] == maximum:
            winner = None
    return winner


def get_square_color(square):
    color = [0, 0, 0]
    for i in range(4):
        for j in range(3):
            color[j] += square[i] * PlayerColors[PlayerNumbers[i]][j]
    return color


def display(screen):
    screen.fill([0, 0, 0])  # Clears the screen with black.

    # Drawing the board
    for i in range(size):
        for j in range(size):
            square = board[i][j][:4]

            # Determining the color of each square.
            color = [int(255 * (1 - 1 / (2 ** (get_square_color(square)[0] / 1.5)))),
                     int(255 * (1 - 1 / (2 ** (get_square_color(square)[1] / 1.5)))),
                     int(255 * (1 - 1 / (2 ** (get_square_color(square)[2] / 1.5))))]

            pygame.draw.rect(screen, color, [50 + (20 * i), 50 + (20 * j), 20, 20])  # Draws the square.
            # Determining whether there is a border.
            player = whose_square(i, j)
            neighbors = [[-1, 0], [0, -1], [1, 0], [0, 1]]
            for neighbor in neighbors:
                if 0 <= i + neighbor[0] < size and 0 <= j + neighbor[1] < size:
                    if player != whose_square(i + neighbor[0], j + neighbor[1]):  # Drawing the boarders
                        if player is None:
                            color = [127, 255, 255]
                        else:
                            color = [colors[player][0]*255, colors[player][1] * 255, colors[player][2] * 255]
                        pygame.draw.rect(
                            screen,
                            color,
                            [59 + 20 * i + 9 * neighbor[0] - 9 * abs(neighbor[1]),
                             59 + 20 * j + 9 * neighbor[1] - 9 * abs(neighbor[0]),
                             (18 * abs(neighbor[1])) + 2,
                             (18 * abs(neighbor[0])) + 2])

    for player_index in range(4):  # Displays the points of each player.
        name = PlayerNames[PlayerNumbers[player_index]]
        color = [colors[player_index][0] * 255, colors[player_index][1] * 255, colors[player_index][2] * 255]
        font = pygame.font.Font(pygame.font.get_default_font(), 24)
        text = font.render(name + " : " + str(caculate_score(player_index)), False, color)
        screen.blit(text, [100 + 20 * size, 70 + 100 * player_index])


def decay():  # Runs the decay step.
    for i in range(size):
        for j in range(size):
            for player in range(4):
                board[i][j][player] *= .97


def run_round(screen):  # Runs one turn of the game.
    global round_number

    round_number += 1

    moves = []  # Each move is of the form [row, col].
    for i in range(4):
        moves.append(Players[i](process_board(i)))# Getting the moves of each player.

    banned_indexes = []  # Checking whether all the moves are legal
    for i in range(4):
        try:
            if moves[i][0] < 0 or moves[i][0] >= size or type(moves[i][0]) != type(1) or\
                moves[i][1] < 0 or moves[i][1] >= size or type(moves[i][1]) != type(1):
                banned_indexes.append(i)
        except AttributeError or IndexError:
            banned_indexes.append(i)

    add_lights(moves, banned_indexes=banned_indexes)  # Resolving each move.

    decay()  # Makes the entire screen dimmer

    display(screen)  # Draws the screen

    if round_number >= 150:
        return

    pygame.display.flip()  # Updates the screen.
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            break
    pygame.time.wait(100)
    run_round(screen)


run_round(screen)
for i in range(4):
    print(PlayerNames[PlayerNumbers[i]] + ": " + str(caculate_score(i)))
input("Press enter to quit")
pygame.quit()
